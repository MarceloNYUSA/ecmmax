import boto3
import json
from botocore.exceptions import ClientError

# need to add in configuration file as environment variables
cluster_arn = 'arn:aws:rds:us-west-2:037579909321:cluster:database-1'
secret_arn = 'arn:aws:secretsmanager:us-west-2:037579909321:secret:dev/aurora/postgres-Ly3Awp'

rds_data = boto3.client('rds-data')


class PostgresqlDB(object):

    def execute_query(self, sql_query, parameters=[]):
        response = []
        try:
            response = rds_data.execute_statement(resourceArn=cluster_arn,
                                                secretArn=secret_arn,
                                                database='test',
                                                sql=sql_query,
                                                parameters=[])
            return response
        except Exception as e:
            print("Exception while connecting to db",e)
        return response




