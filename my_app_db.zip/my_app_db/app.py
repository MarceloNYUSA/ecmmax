import json
import logging
from chalice import Chalice
from chalicelib import db

logger = logging.getLogger()
logger.setLevel(logging.INFO)

columns = ['name', 'estab_id', 'address', 'latitude', 'longitude']
sql_query = "select * from estabs_tbl"

app = Chalice(app_name='my_app_db')


@app.route('/')
def index():

    cnx = db.PostgresqlDB()
    response = cnx.execute_query(sql_query)
    f_res = []
    if response:
        for record in response['records']:
            res = []
            for rec in record:
                for k, v in rec.items():
                    res.append(v)

            values = {columns[i]: res[i] for i in range(len(columns) - 1)}
            f_res.append(values)

    logger.info("fetch the data Successfully", response)
    return json.dumps(f_res)

